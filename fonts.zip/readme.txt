This font are licensed under the Creative Commons Zero v1.0 Universal.

You can use them freely in your products & projects - print or digital, commercial or otherwise.

For more information about this font, go to
https://ggbot.itch.io/crayon-libre-font
https://www.ggbot.net